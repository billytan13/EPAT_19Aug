package sg.edu.nus.iss.epat.tdd.workshop;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class ToDoListTest extends TestCase {
   // Define Test Fixtures

   public ToDoListTest() {
      super();
   }

   @Before
   public void setUp() throws Exception {
      // Initialise Test Fixtures
   }

   @After
   public void tearDown() throws Exception {
      // Uninitialise test Fixtures
   }

   @Test
   public void testAddTask() {
      fail("Not implemented yet");
   }

   @Test
   public void testGetStatus() {
      fail("Not implemented yet");
   }

   @Test
   public void testRemoveTask() {
      fail("Not implemented yet");
   }

   @Test
   public void testGetCompletedTasks() {
      fail("Not implemented yet");
   }
}
